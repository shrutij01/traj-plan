clear all;


Nr = 150;
Na = 150;

deltheta = pi/(Na - 1);
tau = 2*sqrt(2)/(Nr - 1);

hvec = zeros(Nr, 1);

size(hvec)

for i = 1:Nr
    hvec(i,1) = h(i-1, tau);
end

hhat = fft(hvec);

pdata = (ProjectionData(Nr,Na))';
qdata = zeros(Nr,Na);
qdata1 = zeros(Nr,Na);

%size(pdata)
%size(qdata)
%size(hvec)

%plot(pdata)

for angles = 1:Na
    qdata1(:, angles) = fft(pdata(:, angles)).*fft(hvec);
    qdata(:, angles) = ifft(qdata1(:,angles));
end



plot(qdata)

%plot(pdata)

%size(pdata)

