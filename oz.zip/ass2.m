clear all;
N_rays = 150;
N_angles = 150;

P = (ProjectionData(N_rays, N_angles))';
% imshow(P);

n_a = N_angles;
n_r = N_rays;

del_theta = pi/(n_a-1);
tau = (2*sqrt(2))/(n_r-1);
theta = 0 : del_theta : pi;
t = -sqrt(2) : tau : sqrt(2);

h = zeros(n_r, 1);
for n = 1:n_r
    if ((n-1) == 0)
        h(n) = 1/(4*tau^2);
    elseif mod(n-1,2) == 0
        h(n) = 0;
    elseif mod(n-1,2) ~= 0
        h(n) = -1/(((n-1)^2)*(pi^2)*(tau^2));
    end
end

q_theta = zeros(n_r, n_a);
q_theta_f = zeros(n_r, n_a);
fft_h = fft(h);

for angle = 1:n_a
    q_theta_f(:,angle) = fft_h.*fft(P(:,angle));
    q_theta(:,angle) = ifft(q_theta_f(:,angle));
end
% for angle = 1 : n_a
%     for n = 0 : n_r - 1
%         for k = 0 : n_r - 1
%             if n == k
%                 q_theta(n+1,angle) = q_theta(n+1,angle) + tau * (1/(4*(tau^2))) * P(ceil(k*tau)+1,angle);
%             elseif mod(abs(n-k),2) ~= 0
%                 q_theta(n+1,angle) = q_theta(n+1,angle) + tau * ((-1)/(((n-k)^2)*(pi^2)*(tau^2))) * P(ceil(k*tau)+1,angle);
%             end
%         end
%     end
% end

% cart = zeros(n_a, 2);
% [cart(:,1), cart(:,2)] = pol2cart(theta, t);
% t_cart = zeros(size(cart(:,1)),n_a);
% for angle = 1:n_a
%     for i = 1:size(cart(:,1))
%             t_cart(i,angle) = cart(i,1)*cos(angle) + cart(i,2)*sin(angle);
%     end
% end

Nx = 10;
Ny = 10;

grid_t = zeros(Nx,Ny,n_a);
nn_t = zeros(Nx, Ny, angle, 3);
for i = 1:Nx
    for j=1:Ny
        for angle = 1:n_a
            grid_t(i,j,angle) = i*cos(angle) + j*sin(angle);     
            [~, indices_temp] = (sort(abs(t - grid_t(i,j,angle))));
            nn_t(i,j,angle,:) = indices_temp(1:3);
        end
    end
end


q_theta_t = zeros(Nx, Ny, n_a);
for i = 1:Nx
    for j=1:Ny
        for angle = 1:n_a
            q_theta_t(i,j,angle) = (q_theta(nn_t(i,j,angle,1),angle)+q_theta(nn_t(i,j,angle,2),angle)+q_theta(nn_t(i,j,angle,3),angle))/3;
        end
    end
end

fxy = zeros(Nx, Ny);

for i = 1:Nx
    for j = 1:Ny
        for angle = 1:n_a
            fxy(i,j) = fxy(i,j) + (pi/n_a)*q_theta_t(i,j,angle);
        end
    end
end

