function [ P ] = ProjectionData(N_ray,N_angle )

tm=1;

centerx=[0 0 0.22 -0.22 0 0 0 -0.08 0 0.06];
centery=[0 -0.0184 0 0 0.35 0.1 -0.1 -0.605 -0.605 -0.605];
A=[0.92 0.874 0.31 0.41 0.25 0.046 0.046 0.046 0.023 0.046];
B=[0.69 0.6624 0.11 0.16 0.21 0.046 0.046 0.023 0.023 0.023];
alpha=[pi/2 pi/2 2*pi/5 3*pi/5 pi/2 0 0 0 0 pi/2];
u=[2 -0.98 -0.02 -0.02 0.01 0.01 0.01 0.01 0.01 0.01];

P=zeros(N_angle,N_ray); %100 angles N rays in each angle with 0 padding
tvec=-sqrt(2)*tm:(2*sqrt(2)*tm)/(N_ray-1):sqrt(2)*tm;
theta=0:pi/(N_angle-1):pi;

for ec=1:1:10      %Loop for 10 ellipses
for k=1:1:N_angle      %Loop for N_angle projections(Angles)
    for j=1:1:N_ray   %Loop for N rays
        a2theta=(A(ec)^2)*((cos(theta(k)-alpha(ec)))^2)+(B(ec)^2)*((sin(theta(k)-alpha(ec)))^2);
        s=sqrt((centerx(ec))^2+(centery(ec))^2);
        gamma=atan2(centery(ec),centerx(ec));
        tp=tvec(j)-s*cos(gamma-theta(k));
        if sqrt(a2theta)>=abs(tp)
        P(k,j)=P(k,j)+(2*(u(ec))*A(ec)*B(ec)*sqrt(a2theta-(tp)^2))/a2theta;
        else
            P(k,j)=P(k,j);
        end
    end
end
end

end