function output = h(n, tau)

n = n-1;
var = n*tau;

var2  = var*var*pi*pi;

if var == 0
    output = 1/(4*tau*tau);
elseif mod(n, 2) == 0
   output = 0;
else
   output = -1/var2;
end