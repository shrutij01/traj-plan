%% for Q1

x = 1:1:30;
h = [1, 1, 1, 1, 1];
L = 15;
out1 = ass3_add(x,h,L);
out2 = ass3_save(x,h,L);
out = conv(x,h,'full');

err1 = sum(abs(out-out1)); 
err2 = sum(abs(out-out2));

%% for Q2

x = (audioread('audio1.wav'))';
h =  [1, 1, 1, 1, 1, -1, -1, -1, -1, -1]; 
L = 300;

out1 = ass3_add(x,h,L);
out2 = ass3_save(x,h,L);

out = conv(x,h,'full');

err1 = sum(abs(out-out1)); 
err2 = sum(abs(out-out2));
 
