Ts = 0.1;

b = [3, -4];
a = [3, -2.4, 1, -0.7];

% syms s;
% tf0 = (3*s - 4)/(3*(z^3) - 2.4*(z^2) + z - 0.7);
% iztrans(tf0)

[r, p, k] = residue(b,a);

[zeros, poles, gain] = tf2zp(b,a);
zplane(zeros,poles)
grid

syms z;
tf1 = 2/(1 - 0.3*(z^(-1)));
tf2 = 4/(1-(z^(-1)));
tf = tf1 + tf2;
itf = iztrans(tf);

syms n;
% n = tf('n');
f = (((1/3)^n) + ((-1/2)^n))*heaviside(n);
fz = ztrans(f);
[numfz, denfz] = numden(fz);
Hfz = tf(sym2poly(numfz),sym2poly(denfz),Ts);
pzmap(Hfz)
grid
% zerosfz = [0.0000 + 0.4082i, 0.0000 + 0.4082i];
% polesfz = [-1/2, 1/3];
% zplane(zerosfz,polesfz)
% grid

fdisc = [4, 2, 6, 1, 2, 0];
l = length(fdisc);
zout = 0;
z = sym('z');
for i = 0:l-1
    zout = zout + fdisc(i+1)*z^(-i);
end
disp(zout)
% ztransf = ztrans(zout);

syms k z
symsum(2*k*(z^(-k)), k, 0, Inf)

syms y(n) x(n)
y(n) = 0.4*y(n-1) + x(n);
fZT = ztrans(y(n),n,z);
fZT = collect(fZT);
[numfZT, denfZT] = numden(fZT);
HfZT = tf(sym2poly(numfZT), sym2poly(denfZT),Ts);
pzmap(HfZT)