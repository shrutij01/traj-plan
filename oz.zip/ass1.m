% plotting a 2KHz sine wave in the continuous and the discrete domains over
% 5 cycles

%% continuous domain signal
Fs = 50000; %Sampling rate              
dt = 1/Fs;  %one cycles is dt seconds long
cycles = 5; %number of signal cycles to be plotted
Fc = 2000;  %signal frequency
stop = (cycles/Fc);

t = (0:dt:stop)';     
x = sin(2*pi*Fc*t);

figure;
plot(t,x);
xlabel('Time(s)');
title('Signal versus Time');
zoom xon;

%% Discrete domain signal
N = 50*2.5; % 50K samples in a second => 50*2.5 samples in 5 cycles
n = 0 : 1 : N-1;

% Fs = 3*pi*Fc;
% Fs = 3*Fc;
% Fs = (5/3)*Fc;
Fs=7*Fc;

y = sin(2*pi*Fc*n/Fs);

figure;
stem(n,y);
xlabel('Time(s)');
title('Signal versus Time');
zoom xon;

%% magnitude spectrum using fft 

m = fft(y)./numel(y);
% m = fft(x);
L = N;
% L = stop/dt;
ds = abs(m/L);
ss = ds(1:L/2);
ss(2:end-1) = 2*ss(2:end-1);

f = Fs*(0:(L/2-1))/L;
plot(f,ss);
xlabel('Frequency (f)')
ylabel('|signal(f)|')