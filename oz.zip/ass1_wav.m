[y, Fs] = audioread('audio1.wav');
% info = audioinfo('audio1.wav');
freq = (Fs)*(10^(-3));
fprintf('Sampling rate is %d kHz \n',freq);
% disp('Sampling Rate is',freq,'kHz');
% Fs = (info.SampleRate)*(10^(-3));
sound(y, Fs);

A1 = 0.7;
A2 = 0.7;
A3 = 0.7;
N1 = ceil(Fs *(17.15/343));
N2 = ceil(Fs * (8.575/343));
N3 = ceil(Fs * (8.575/343));

[last,~] = size(y);
e1 = zeros(last+N1,1);
e1(N1:(last+N1-1)) = y;
e2 = zeros(last+N2,1);
e2(N2:(last+N2-1)) = y;
e3 = zeros(last+N3,1);
e3(N3:(last+N3-1)) = y;

final = y + A1*e1(1:last) + A2*e2(1:last) + A3*e3(1:last);
sound(final,Fs);
m = fft(final)./numel(final);
% m = fft(x);
L = Fs;
% L = stop/dt;
ds = abs(m/L);
ss = ds(1:L/2+1);
ss(2:end-1) = 2*ss(2:end-1);

f = Fs*(0:L/2)/L;
plot(f,ss);
xlabel('Frequency (f)')
ylabel('System Response')

[y2, Fs2] = audioread('audio2.wav');

[r1,lag1] = xcorr(y,y);
[r2,lag2] = xcorr(y2,y2);

plot(lag1,r1);
plot(lag2,r2);
